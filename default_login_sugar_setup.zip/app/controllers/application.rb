# Filters added to this controller will be run for all controllers in the application.
# Likewise, all the methods added will be available for all controllers.

require 'user_system'

class ApplicationController < ActionController::Base
    include Localization
    include UserSystem
    helper :user
    model :user
    before_filter :login_required

end
